<?php
$connection = mysqli_connect('localhost','root','','reservation') or die(mysqli_error($connection));
?>